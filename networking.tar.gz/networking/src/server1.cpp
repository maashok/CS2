/**
@file
@author Ben Yuan
@date 2013
@copyright 2-clause BSD; see License section

@brief
A multi-user echo server to validate the network wrapper.

@section License

Copyright (c) 2012-2013 California Institute of Technology.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the California Institute of Technology.

*/

#include "server1.hpp"
#include <iostream>
using namespace CS2Net;

int main(int argc, char ** argv)
{

    REQUIRE(argc == 2, "usage: %s port", argv[0]);
	// Set up a listener socket and one that can accept new connections
    CS2Net::Socket listener;
	CS2Net::Socket *incoming_conn = NULL;
	
	// Bind the listener to port with only allowing backlog of 3 
	// connections
	int possErr = listener.Bind(atoi(argv[1]), 3);
	REQUIRE(possErr == 0, "Binding failure");
	
	// Set up a poll vector with the listener socket for reading
	std::vector<CS2Net::PollFD> poll_vec(1);
	poll_vec[0].sock = &listener;
	poll_vec[0].SetRead(true);
	// Have a poll vector with all the sockets that connect to the server
	std::vector<CS2Net::PollFD> connections;
	
    while (true) {
		// Poll all the connected sockets to see if we got anything
		// with 10 ms timeout
		int poll_err = CS2Net::Poll(&connections, 10);
		REQUIRE(poll_err >= 0, "poll error");
		// Go through the connections and see if we can read anything
		// from that socket
		for(int j = 0; j < connections.size(); j++) {
			// If a connection has hangup or some other error, disconnect
			// it
			if (connections[j].HasHangup() || connections[j].HasError()) {
				connections.erase(connections.begin() + j);
				continue;
			}
			// But if we can read anything, receive the message (checking
			// we do get something) and broadcast it to all the connections
			if (connections[j].CanRead()) {
				std::string *incoming = connections[j].sock->Recv(1024, false);
				if (incoming == NULL) {
					ERROR("Receiving error: %s", strerror(errno));
				}
				else  {
					// Sending this message to all connections
					for (int i = 0; i < connections.size(); i++) {
						int ret = connections[i].sock->Send(incoming);
						if (ret < 0) {
							// Check if sending caused any errors
							if (ret == -1)
								ERROR("Sending error :%s", strerror(errno));
							else
								ERROR("Something else wrong");
						}
					}
				}
			}
		}
		// Now poll the poll_vec to see if we got any new connections
		int err = CS2Net::Poll(&poll_vec, 10);
		REQUIRE(err >= 0, "poll error");
		// If the listener polling itself has hangup or error, 
		// exit
		if (poll_vec[0].HasHangup() || poll_vec[0].HasError()) {
			ERROR("Hang up or error");
			return -1;
		}
		// If we get something to read, accept the connection
		if (poll_vec[0].CanRead()) {
			incoming_conn = listener.Accept();
			REQUIRE(incoming_conn != NULL, "Not accepting");
			// Add this socket to our list of connections
			CS2Net::PollFD newSock;
			newSock.sock = incoming_conn;
			newSock.SetRead(true);
			connections.push_back(newSock);
		}
	}
    return 0;

}

