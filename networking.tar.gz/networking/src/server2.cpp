/**
@file
@author Ben Yuan
@date 2013
@copyright 2-clause BSD; see License section

@brief
The server executable.

@section License

Copyright (c) 2012-2013 California Institute of Technology.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the California Institute of Technology.

*/

#include "server2.hpp"
#include <iostream>

/** Note:
 * The user list is only updated when one of the users tries to send
 * a message to all the other connected users, and finds out that some
 * user has disconnected. At the same time, the users will get a message
 * that that user has left the server.
 * 
 * This is similar to what would happen in a chat room as there will
 * be many connected clients, continuing to message each other even
 * after a client leaves, making sure that the clients know soon enough
 * (when they try to contact all the clients) that one of the clients
 * has left.
 * 
 * (This was examined with help from Cody in office hours)
 * 
 */



int main(int argc, char ** argv)
{

    REQUIRE(argc == 2, "usage: %s port", argv[0]);
	// Set up a listener socket and one that can accept new connections
    CS2Net::Socket listener;
	CS2Net::Socket *incoming_conn = NULL;
	
	// Bind the listener to port with only allowing backlog of 5
	// connections
	int possErr = listener.Bind(atoi(argv[1]), 5);
	REQUIRE(possErr == 0, "Binding failure");
	
	// Set up a poll vector with the listener socket for reading
	std::vector<CS2Net::PollFD> poll_vec(1);
	poll_vec[0].sock = &listener;
	poll_vec[0].SetRead(true);
	
    while (true) {
		// Poll all the connected sockets to see if we got anything
		// with 10 ms timeout
		int poll_err = CS2Net::Poll(&connections, 10);
		REQUIRE(poll_err >= 0, "poll error");
		// Go through the connections and see if we can read anything
		// from that socket
		for(int j = 0; j < connections.size(); j++) {
			// If a connection has hangup or some other error, disconnect
			// it and let the other users know
			if (connections[j].HasHangup() || connections[j].HasError()) {
				std::string disconMsg = connections[j].name;
				connections.erase(connections.begin() + j);
				disconMsg.append(" has exited the server");
				// Send the message that the user has left the server
				// to all connected users
				std::string leaveSend = EncodeNetworkMessage(MSG_SERVER_MESSAGE, &disconMsg);
				for (int m = 0; m < connections.size(); m++) {
					int ret = connections[m].sock->Send(&leaveSend);
					if (ret < 0) {
					// Check if sending caused any errors
					if (ret == -1)
						ERROR("Sending error :%s", strerror(errno));
					else
						ERROR("Something else wrong");
					}
				}
				// Update the user list of all connected users
				std::string usrs = "";
				for (int k = 0; k < connections.size(); k++) {
					usrs.append(connections[k].name + "\n");
				}
				std::string usersSend = EncodeNetworkMessage(MSG_USERLIST, &usrs);
				for (int l = 0; l < connections.size(); l++) {
					int ret = connections[l].sock->Send(&usersSend);
					if (ret < 0) {
						// Check if sending caused any errors
						if (ret == -1)
							ERROR("Sending error :%s", strerror(errno));
						else
							ERROR("Something else wrong");			
					}
				}
				continue;
			}
			// But if we can read anything, handle the message
			// appropriately
			if (connections[j].CanRead()) {
				handleMsg(j);
			}
		}
		// Now poll the poll_vec to see if we got any new connections
		int err = CS2Net::Poll(&poll_vec, 10);
		REQUIRE(err >= 0, "poll error");
		// If the listener polling itself has hangup or error, 
		// exit
		if (poll_vec[0].HasHangup() || poll_vec[0].HasError()) {
			ERROR("Hang up or error");
			return -1;
		}
		// If we get something to read, accept the connection
		if (poll_vec[0].CanRead()) {
			incoming_conn = listener.Accept();
			REQUIRE(incoming_conn != NULL, "Not accepting");
			// Add this socket to our list of connections
			CS2Net::PollFD newSock;
			newSock.sock = incoming_conn;
			newSock.SetRead(true);
			connections.push_back(newSock);
		}
	}
    return 0;
}



void handleMsg(int j) {
	std::string *incoming = connections[j].sock->Recv(1, true);
	if (incoming == NULL) {
		ERROR("Receiving error: %s", strerror(errno));
		return;
	}
	// If the message type is a chat message
	if ((MESSAGE_TYPE)(*(incoming->c_str())) == (MESSAGE_TYPE)(MSG_CHATMSG)) {			
		// Read the next two bytes (Size) and then get that much
		// data. This data will be added to the buffer
		std::string *size = connections[j].sock->Recv(2, false);
		unsigned short __size = *(unsigned short *)(size->data());
		if (__size != 0) {
			std::string *msg = connections[j].sock->Recv(__size, false);
			std::string __msg = "[";
			__msg.append(connections[j].name);
			__msg.append("] ");
			__msg.append(*msg);
			// Rebroadcast the message to all connected users
			for (int i = 0; i < connections.size(); i++) {
				std::string chatMsg = EncodeNetworkMessage(MSG_CHATMSG, &__msg);
				int ret = connections[i].sock->Send(&chatMsg);
				if (ret < 0) {
					// Check if sending caused any errors
					if (ret == -1)
						ERROR("Sending error :%s", strerror(errno));
					else
						ERROR("Something else wrong");
				}
			}
		}
	}
	// If the message is of type user authentification
	else if ((MESSAGE_TYPE)(*(incoming->c_str())) == (MESSAGE_TYPE)(MSG_AUTH_USERNAME)) {			
		// Read the next two bytes (Size) and then get that much
		// data. This data will be added to the buffer
		std::string *size = connections[j].sock->Recv(2, false);
		unsigned short __size = *(unsigned short *)(size->data());
		if (__size != 0) {
			std::string *usrname = connections[j].sock->Recv(__size, false);
			const char *__usrname = usrname->c_str();
			std::string blank = "";
			// User name is not valid if it contains any new line characters
			for (int i = 0; i < usrname->length(); i++) {
				if (__usrname[i] == '\n') {
					// If there are new line chars, send out 
					// authentification error message
					std::string bad = EncodeNetworkMessage(MSG_AUTH_ERROR, &blank);
					int ret = connections[j].sock->Send(&bad);
					if (ret < 0) {
						// Check if sending caused any errors
						if (ret == -1)
							ERROR("Sending error :%s", strerror(errno));
						else
							ERROR("Something else wrong");
					}
					return;
				}
			}
			// If the username is valid, send a Authentification OK message
			connections[j].name = *usrname;
			std::string good = EncodeNetworkMessage(MSG_AUTH_OK, &blank);
			int ret = connections[j].sock->Send(&good);
			if (ret < 0) {
				// Check if sending caused any errors
				if (ret == -1)
					ERROR("Sending error :%s", strerror(errno));
				else
					ERROR("Something else wrong");			
			}
			
			// Sleep for a second to allow the client to finish connecting
			// to the server before we send out any further information
			// about this event to all connected clients
			sleep(1);
			std::string connectedMsg = *usrname;
			std::string usrs = "";
			connectedMsg.append(" has joined the server");
			// Let all connected users know that this current user has
			// joined the server
			std::string joinSend = EncodeNetworkMessage(MSG_SERVER_MESSAGE, &connectedMsg);
			for (int k = 0; k < connections.size(); k++) {
				ret = connections[k].sock->Send(&joinSend);
				if (ret < 0) {
					// Check if sending caused any errors
					if (ret == -1)
						ERROR("Sending error :%s", strerror(errno));
					else
						ERROR("Something else wrong");			
				}
				usrs.append(connections[k].name + "\n");
			}
			// Sleep for a second again to allow the clients to finish
			// getting this information about a new client joining
			// Then update the userlist of all the clients (just a list
			// of the user names separated by \n)
			sleep(1);
			std::string usersSend = EncodeNetworkMessage(MSG_USERLIST, &usrs);
			for (int l = 0; l < connections.size(); l++) {	
				ret = connections[l].sock->Send(&usersSend);
				if (ret < 0) {
					// Check if sending caused any errors
					if (ret == -1)
						ERROR("Sending error :%s", strerror(errno));
					else
						ERROR("Something else wrong");			
				}
			}
		}
	}
		
}

