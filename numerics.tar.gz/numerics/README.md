Caltech CS2 Assignment 8: Numerics

See [assignment8.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/numerics/blob/master/assignment8.html)

Note:
Kahan part answers in a README file in Kahan subdirectory
Orbits part answers in a README file in orbits subdirectory

Fourier Transform Answers:
The Fourier transform of a pure sine wave would just look like the
same sine wave, as Fourier transform approximates a function as a sum
of sine and cosine functions.

The DFT of the same signal would just have one vertical peak at the
frequency of the sine wave (x axis of DFT is frequency) and one vertical
peak at the x value of the negative frequency, since the DFT converts 
a function from the time to frequency domain, and a pure sine wave has 
one constant frequency (but we are working with complex numbers - thus
the two peaks). 

As the function becomes more complicated, the Fourier transform will 
become more complicated, as one must express the complex function as
a sum of sines and cosines, and this may involve many components.
Also, the DFT will become more complicated, as there will be multiple
frequencies, and there must be vertical lines at each of these frequencies
and their corresponding negative frequencies to signify the frequencies 
present in the signal.
