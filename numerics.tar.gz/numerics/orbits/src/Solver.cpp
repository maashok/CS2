/**
 * @file Solver.cpp
 * @author Ellen Price <<eprice@caltech.edu>>
 * @version 1.0
 * @date 2013-2014
 * @copyright see License section
 *
 * @brief Functions that carry out numerical root-finding.
 *
 * @section License
 * Copyright (c) 2013-2014 California Institute of Technology.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above
 *   copyright notice, this list of conditions and the following disclaimer
 *   in the documentation and/or other materials provided with the
 *   distribution.
 * * Neither the name of the  nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are those
 * of the authors and should not be interpreted as representing official policies,
 * either expressed or implied, of the California Institute of Technology.
 *
 */

#include "Solver.hpp"

#define PRECISION       (1.e-10)
#define TOLERANCE       (1.e-10)
#include <cstdio>
using namespace std;


/**
 * @brief Solves f(x) = 0 in the interval [x1, x2] with the bisection
 * method
 *
 * @param[in] f The function to solve
 *
 * @param[in] x1 One side of the interval to search
 *
 * @param[in] x2 The other side of the interval to search
 *
 * @return The x-coordinate of the root
 */
double Solver::bisection(double (*f)(double), double x1, double x2)
{
	// Precondition: f(x1) and f(x2) are of different signs
	// Store the error
	double error = 1.0;
	double mdpt;
	// Continue while the size of the interval is greater than the 
	// precision we want
	while (abs(error) > PRECISION) {
		// Approximate the midpoint to see if the midpoint equals zero
		mdpt = (x1 + x2)/2;
		// If the midpoint equals zero, we have found the root
		if (f(mdpt) == 0) {
			return mdpt;
		}
		// If both the midpoint and left coordinate are of the same sign,
		// shrink the interval from midpoint to right coordinate
		if ((f(mdpt) > 0 && f(x1) > 0) || (f(mdpt) < 0 && f(x1) < 0)) {
			x1 = mdpt;
		}
		// Otherwise, shrink the interval from left coordinate to 
		// midpoint
		else {
			x2 = mdpt;
		}
		// The error becomes the size of this interval
		error = abs(x2-x1);
	}
	// Once the interval is smaller than the precision, the x1 is a
	// good enough approximation of the root
    return x1;
}


/**
 * @brief Solves f(x) = 0 near x1 with the Newton-Raphson method
 *
 * @param[in] f The function to solve
 *
 * @param[in] fp The first derivative of f
 *
 * @param[in] x1 A starting point for the solver
 *
 * @return The x-coordinate of the root
 */
double Solver::newton_raphson(double (*f)(double), double (*fp)(double),
    double x1)
{
	// Save the start point in case our x1 is not good enough and
	// we decide to start the method again with a different but
	// close start point
	double startpt = x1;
	// Continue while our error is greater than the tolerance limit
	while (abs(f(x1)/fp(x1)) > TOLERANCE) {
		// If our point that we are looking at is zero, we have found
		// the root
		if (f(x1) == 0) return x1;
		// If the derivative is zero at x1, we can't use the Taylor
		// series expansion, and need to start with some other start point
		if (fp(x1) == 0) {
			double soln = newton_raphson(f, fp, startpt + 0.5);
			return soln;
		}
		// Using the taylor Series expansion up to two terms, the new
		// point we can look at is the current point minus the 
		// derivative at this point divided by the value of f at this point.
		x1 = x1 - f(x1)/fp(x1);
	}	
	// Once our error is smaller than tolerance, x1 is a good enough
	// approximation of the root
    return x1;
}
