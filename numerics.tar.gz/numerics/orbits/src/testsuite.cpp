/**
 * @file test_solver.cpp
 * @author Ellen Price <<eprice@caltech.edu>>
 * @version 1.0
 * @date 2013-2014
 * @copyright see License section
 *
 * @brief Simple test suite for Solver.
 *
 * @section License
 * Copyright (c) 2013-2014 California Institute of Technology.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above
 *   copyright notice, this list of conditions and the following disclaimer
 *   in the documentation and/or other materials provided with the
 *   distribution.
 * * Neither the name of the  nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * The views and conclusions contained in the software and documentation are those
 * of the authors and should not be interpreted as representing official policies,
 * either expressed or implied, of the California Institute of Technology.
 *
 */

#include "Solver.hpp"
#include <cstdio>

using namespace Solver;



double poly5(double x) {
	return x*x*x*x*x + x*x*x*x + x*x + 3;
}
double poly5p(double x) {
	return 5*x*x*x*x + 4*x*x*x + 2*x;
}

double mysine(double x) {
	return sin(x);
}
double mycos(double x) {
	return cos(x);
}

double ration(double x) {
	return (x-1)/(x-10);
}
double rationp(double x) {
	return ((x-10) - (x-1))/((x-10)*(x-10));
}

double nonanaly1(double x) {
	return sin(x) - 5*x*x;
}
double nonanaly1p(double x) {
	return cos(x) - 10*x;
}

double nonanaly2(double x) {
	return log(x) - cos(x);
}
double nonanaly2p(double x) {
	return 1/x + sin(x);
}

double nonanaly3(double x) {
	return tan(x) + 1/x;
}
double nonanaly3p(double x) {
	return 1/(cos(x)*cos(x)) - 1/(x*x);
}

int main()
{
	printf("Testing analytically solvable equations\n\n");
    printf("Solving x^5 + x^4 + x^2 + 3\n");
    printf("The correct answer is -1.70232\n");
    double ans = bisection(poly5, -5., 5.);
    printf("The bisection method says the answer is %f\n", ans);
    double ans2 = newton_raphson(poly5, poly5p, 0.);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    
    printf("Solving sin(x)\n");
    printf("The correct answers are -3.1415927, 0, 3.1415927, etc.\n");
    ans = bisection(mysine, -2, 2);
    printf("The bisection method says the answer is %f\n", ans);
    ans2 = newton_raphson(mysine, mycos, 2.);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    
    printf("Solving (x-1)/(x-10)\n");
    printf("The correct answer is 1\n");
    ans = bisection(ration, -5., 5.);
    printf("The bisection method says the answer is %f\n", ans);
    ans2 = newton_raphson(ration, rationp, 0.);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    
    printf("Testing non-analytically solvable equations\n\n");
    
    printf("Solving sin(x) - 5x^2\n");
    printf("The correct answers are 0, 0.198687\n");
    ans = bisection(nonanaly1, 0.1, 2);
    printf("The bisection method says the answer is %f\n", ans);
    ans2 = newton_raphson(nonanaly1, nonanaly1p, 0.1);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    
    printf("Solving ln(x) - cos(x)\n");
    printf("The correct answer is 1.302964\n");
    ans = bisection(nonanaly2, 0., 2.);
    printf("The bisection method says the answer is %f\n", ans);
    ans2 = newton_raphson(nonanaly2, nonanaly2p, 2.);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    
    printf("Solving tan(x) + 1/x\n");
    printf("The correct answers are +/-2.798386046, +/-6.1212504467, etc.\n");
    ans = bisection(nonanaly3, 2, 3);
    printf("The bisection method says the answer is %f\n", ans);
    ans2 = newton_raphson(nonanaly3, nonanaly3p, -3.);
    printf("The Newton-Raphson method says the answer is %f\n", ans2);
    printf("\n");
    return 0;
}

