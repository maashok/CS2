Philosophers
1) The greedy algorithm works so that each philosopher continually picks up
his left and right forks when he can, and eats with the forks, after
which he relinquishes them. Each of the philosopher continually repeats
this process.

This solution will always deadlock since when it starts out, each 
philosopher will grab their left fork at the exact same time when
starting, at which point they will all wait forever to grab their
right fork. However, since none of them will be able to get to the point
at which they drop their forks, they will always keep on waiting for a fork.
Even if you stagger the start times to avoid this deadlock, this same
problem will occur at some time, where two philosophers sitting
next to each other both grab their left forks at the exact same time.

2) 
/** THIS ANSWER WAS WRONG */
If there are 5 philosophers total (and 5 forks), then only 2 people
can sit at the table at any one time. This is because, each philosopher
needs 2 forks to eat, and two philosophers will use 4 of the forks
at one time, and there is only 1 fork left over, which is not useful.
If we try to place 3 philosophers at the table, they will need 6 forks,
which is more forks than the number available.
(In this use of waiters, we only allow philosophers to sit at the table
if they can eat. Otherwise, they can think without sitting at the table.
When it's their turn to eat, they can come to the table.)

In general, the maximum number of philosophers who can sit at the table
at any one time, is half of the number of philosophers (rounded down),
since each philosopher needs 2 forks, and there are only as many forks
available as philosophers.

/** THIS ANSWER IS RIGHT */
A maximum of 4 philosophers can sit at the table. This way, with 5 forks,
one philosopher is guaranteed to pick up two forks and can eat, after which
he relinquishes the forks and then some other philosopher must pick up 
2 forks. When there are 5 philosophers, there is a chance each picks up one
fork, meaning there are none left over. But by removing one philosopher
we make sure that at any time, even if every philosopher picks up their left
fork, one philosopher will also have a right fork to pick up.

3) If every philosopher began with dirty, left forks, they would each
send a request message to the person on their right, too get the fork.
And since the fork is dirty, the philosopher on the right will give it
up. However, they will have to clean it when they give the fork up.
At this point, every philosopher has a clean right fork. They will each
send a request to another philosopher for a left fork, but will none of
the philosophers will give a fork up since the fork they has is clean,
and it will never get dirty since none of them gain another fork to eat.
