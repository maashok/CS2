#include "RaytracerMultithreaded.h"

void main() {
	World *w = new World();
	Shader *s = new Shader();
	RaytracerMultithreaded *test = new RaytracerMultithreaded(w, s);
	test->runSpecial(true);
	delete test;
}
