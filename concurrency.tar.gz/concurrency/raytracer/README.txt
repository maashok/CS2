When using memcheck target in the Makefile to check memory leaks, if we look at the file memcheck.full, none of the 
memory leaks are caused by the file RaytracerMultithreaded.cpp, which is the file I modified. Thus, all the memory leaks
are caused by the complex memory leaks inherent with using graphics packages and such outside libraries.